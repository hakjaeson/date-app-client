import React from "react";
import { Anniversary } from "../../styles/diarystyles/mainpage/mainpagestyle";

const AnniversaryContent = ({ data }) => {
  // const startAt = data[0].nm;
  return (
    <Anniversary>
      <span>D + 1000</span>
    </Anniversary>
  );
};

export default AnniversaryContent;
