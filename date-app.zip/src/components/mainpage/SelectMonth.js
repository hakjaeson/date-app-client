import React from "react";

const SelectMonth = () => {
  return <div>반갑다 이말이야</div>;
};

export default SelectMonth;
