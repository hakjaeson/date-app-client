import axios from "axios";

// 해당 게시물 상세페이지 데이터 가져오기
export const getReadPage = async (_setData, _diaryId, _setEmojiName) => {
  const res = await axios.get("mainPage.json");
  _setData(res.data[_diaryId]);
  _setEmojiName(res.data[_diaryId].emoji - 1);
};
