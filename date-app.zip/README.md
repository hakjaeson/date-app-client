###

module version :

"@emotion/react": "^11.11.1",
"@emotion/styled": "^11.11.0",
"@fortawesome/fontawesome-svg-core": "^6.5.1",
"@fortawesome/free-brands-svg-icons": "^6.5.1",
"@fortawesome/free-regular-svg-icons": "^6.5.1",
"@fortawesome/free-solid-svg-icons": "^6.5.1",
"@fortawesome/react-fontawesome": "^0.2.0",
"axios": "^1.6.2",
"eslint-config-prettier": "^9.1.0",
"normalize.css": "^8.0.1",
"react": "^18.2.0",
"react-beautiful-dnd": "^13.1.1",
"react-dnd": "^16.0.1",
"react-dom": "^18.2.0",
"react-draggable": "^4.4.6",
"react-hook-form": "^7.48.2",
"react-router": "^6.20.1",
"react-router-dom": "^6.20.1",
"react-scripts": "5.0.1",
"swiper": "^11.0.4"
